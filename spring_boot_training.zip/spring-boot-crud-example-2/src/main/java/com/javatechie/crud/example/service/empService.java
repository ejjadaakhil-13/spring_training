package com.javatechie.crud.example.service;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javatechie.crud.example.entity.emp;
import com.javatechie.crud.example.repository.Emprepo;

@Service
public class empService {

    @Autowired
    private Emprepo repos;
    
    public List<emp> getemp() {
    	
        return repos.findAll();
    }
    
    public emp saveemp(emp _emp) {
    	
        return repos.save(_emp);
    }
   
    public List<emp> saveallemps(List<emp> _emp) {
    	
    	return repos.saveAll(_emp);
    }
    
    
    
    public emp updateemp(emp _emp) {
       
    	Optional<emp> optionalOldemp = repos.findById(_emp.getEmp_profile_empid());
        
    	if (optionalOldemp.isPresent()) {
           
    		emp oldemp = optionalOldemp.get();
            
    		oldemp.setEmp_profile_loginid(_emp.getEmp_profile_loginid());
            
    		oldemp.setEmp_profile_doctorid(_emp.getEmp_profile_doctorid());
            
    		oldemp.setEmp_profile_is_active(_emp.isEmp_profile_is_active());
            
    		return repos.save(oldemp);
        } 
        
    	else {
        
    		return null;
        	
    	}
    }


   
}
    
    
