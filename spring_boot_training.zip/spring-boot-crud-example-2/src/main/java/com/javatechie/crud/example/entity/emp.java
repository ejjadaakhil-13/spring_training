package com.javatechie.crud.example.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "emp_profile")

public class emp {
	@Id
	@Column(name="emp_profile_empid")
	private int emp_profile_empid ; 
	
	@Column(name="emp_profile_loginid")
	private  int emp_profile_loginid;
	
	@Column(name="emp_profile_doctorid")
	private String  emp_profile_doctorid;

	private boolean emp_profile_is_active;

	public int getEmp_profile_empid() {
		
		return emp_profile_empid;
}

	public void setEmp_profile_empid(int emp_profile_empid) {
	
		this.emp_profile_empid = emp_profile_empid;
}

	public int getEmp_profile_loginid() {
		
		return emp_profile_loginid;
}

	public void setEmp_profile_loginid(int emp_profile_loginid) {
		
		this.emp_profile_loginid = emp_profile_loginid;
}

	public String getEmp_profile_doctorid() {
		
		return emp_profile_doctorid;
}

	public void setEmp_profile_doctorid(String emp_profile_doctorid) {
		
		this.emp_profile_doctorid = emp_profile_doctorid;
}

	public boolean isEmp_profile_is_active() {
		
		return emp_profile_is_active;
}

	public void setEmp_profile_is_active(boolean emp_profile_is_active) {
		
		this.emp_profile_is_active = emp_profile_is_active;
}


	
}
