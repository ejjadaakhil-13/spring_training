package com.javatechie.crud.example.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.javatechie.crud.example.entity.emp;

public interface Emprepo extends JpaRepository<emp,Integer>{




}
