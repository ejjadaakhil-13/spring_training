package com.javatechie.crud.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.javatechie.crud.example.entity.emp;
import com.javatechie.crud.example.service.empService;

@RestController
public class empController {

	@Autowired
	private empService services;
	
	@GetMapping("/emp")
	public List<emp>getemp(){
		
		return services.getemp();
	}
	
	@PostMapping("/addemp")
    public emp addemp(@RequestBody emp _emp) {
        
		return services.saveemp(_emp);
    }
	
	@PostMapping("/addemps")
	public List<emp> addemps(@RequestBody List<emp> _emp) {
		
		return services.saveallemps(_emp);
	}

	 @PutMapping("/updateemp")
	 public emp updateemp(@RequestBody emp _emp) {
	     
		 return services.updateemp(_emp);
	    }
	
	
	
	}

