package com.javatechie.crud.example.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.javatechie.crud.example.entity.EmployeeEntity;
import com.javatechie.crud.example.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService services;
	
	@GetMapping("/emp")
	public List<EmployeeEntity> getemp(){
		
		return services.getemp();
	}
	
	@GetMapping("/tables")
	public List<EmployeeEntity> data(EmployeeEntity _emp){
		return services.table(_emp);
		
	}
	
	@GetMapping("/empid/{empId}")
	public EmployeeEntity getempbyId(@PathVariable int empId) {
		
		return services.getempbyId(empId);
	}
	
	// 	-------- native query to get details by id
	
	@GetMapping("/byids")
	public List<EmployeeEntity> nids(EmployeeEntity _emp){
		
		return services.id(_emp);
	}
	
	
	// --------	criteria query (select)
	
	@GetMapping("/dataoftables") 
	public List<EmployeeEntity> tablecontents(EmployeeEntity _emp){
		
		return services.tabledata(_emp);
	}
	
	
	//	------- criteria query (where)
	
	@GetMapping("/idemp/{empIds}")
	public List<EmployeeEntity> ids(@PathVariable int empIds){
	
		return services.idemp(empIds);
	}
	
	
	@PostMapping("/addemp")
    public EmployeeEntity addemp(@RequestBody EmployeeEntity _emp) {
        
		return services.saveemp(_emp);
    }
	
	@PostMapping("/addemps")
	public List<EmployeeEntity> addemps(@RequestBody List<EmployeeEntity> _emp) {
		
		return services.saveallemps(_emp);
	}
		
	 @PutMapping("/updateemp")
	 public EmployeeEntity updateemp(@RequestBody EmployeeEntity _emp) {
	     
		 return services.updateemp(_emp);
	    
	 }
	
	 @DeleteMapping("/deleteid/{empId}")
	 public String deletewithid(@PathVariable int empId) {
		 
	     return services.deleteid(empId);
	 }
	 
	
	}

