package com.javatechie.crud.example.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.javatechie.crud.example.entity.EmployeeEntity;

public interface EmployeeRepository extends JpaRepository<EmployeeEntity,Integer>{

	
	  @Query(value="select *from emp_profile", nativeQuery=true)
	  public List<EmployeeEntity> tabledata(EmployeeEntity _emp);
	  
	  @Query(value="select *from emp_profile where emp_profile_empid between 1 and 1000 ", nativeQuery=true)
	  public List<EmployeeEntity> ids(EmployeeEntity _emp);
	  	  
	
	
}

