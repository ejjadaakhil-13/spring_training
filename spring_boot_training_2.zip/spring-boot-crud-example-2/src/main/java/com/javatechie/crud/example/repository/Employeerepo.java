package com.javatechie.crud.example.repository;

import java.util.List;

import javax.persistence.EntityManager;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.javatechie.crud.example.entity.EmployeeEntity;

@Repository
public class Employeerepo {

	    private final EntityManager entityManager;
	    
	    private final CriteriaBuilder criteriaBuilder;
	    
	    private final CriteriaQuery<EmployeeEntity> criteriaQuery;

	    @Autowired
	    public Employeerepo(EntityManager entityManager) {
	    
	    	this.entityManager = entityManager;
	        
	    	this.criteriaBuilder = entityManager.getCriteriaBuilder();
	        
	    	this.criteriaQuery = criteriaBuilder.createQuery(EmployeeEntity.class);
	    }

	    public List<EmployeeEntity> getAllEmployees() {
	        
	    	criteriaQuery.select(criteriaQuery.from(EmployeeEntity.class));
	        
	    	return entityManager.createQuery(criteriaQuery).getResultList();
	    }
	    
	    public List<EmployeeEntity> findingbyempid(int empId) {
	       
	    	criteriaQuery.select(criteriaQuery.from(EmployeeEntity.class));
	       
	        Root<EmployeeEntity> root = criteriaQuery.from(EmployeeEntity.class);
	        
	        criteriaQuery.where(criteriaBuilder.equal(root.get("empId"), empId));

	        return entityManager.createQuery(criteriaQuery).getResultList();
	    }

	    
	}
    
