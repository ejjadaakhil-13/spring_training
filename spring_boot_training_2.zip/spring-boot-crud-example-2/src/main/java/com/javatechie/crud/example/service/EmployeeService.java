package com.javatechie.crud.example.service;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javatechie.crud.example.entity.EmployeeEntity;
import com.javatechie.crud.example.repository.EmployeeRepository;
import com.javatechie.crud.example.repository.Employeerepo;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository repos;
    
    @Autowired
    private Employeerepo cq;
    
    public List<EmployeeEntity> getemp() {
    	
        return repos.findAll();
    }
    
    
    public EmployeeEntity getempbyId(int empId) {
		
    	return repos.getById(empId);
    }
   
    public EmployeeEntity saveemp(EmployeeEntity _emp) {
    	
        return repos.save(_emp);
    }
   
    
    public List<EmployeeEntity> saveallemps(List<EmployeeEntity> _emp) {
    	
    	return repos.saveAll(_emp);
    }

    
    public EmployeeEntity updateemp(EmployeeEntity _emp) {
    	
        Optional<EmployeeEntity> optionalOldEmp = repos.findById(_emp.getEmpId());
 
        if (optionalOldEmp.isPresent()) {
        
        	EmployeeEntity oldEmp = optionalOldEmp.get();
            
        	oldEmp.setDoctorId(_emp.getDoctorId());
            
        	oldEmp.setProfile(_emp.getProfile());
            
        	oldEmp.setProfileLname(_emp.getProfileLname());
            
        	oldEmp.setProfileMi(_emp.getProfileMi());
            
        	oldEmp.setProfileFname(_emp.getProfileFname());
            
        	oldEmp.setProfileFullname(_emp.getProfileFullname());
            
        	oldEmp.setProfileCredentials(_emp.getProfileCredentials());
            
        	oldEmp.setProfileSsn(_emp.getProfileSsn());
            
        	oldEmp.setEmpProfileAddress(_emp.getEmpProfileAddress());
            
        	oldEmp.setEmpProfileCity(_emp.getEmpProfileCity());
            
        	oldEmp.setEmpProfileState(_emp.getEmpProfileState());
            
        	oldEmp.setEmpProfileZip(_emp.getEmpProfileZip());
            
        	oldEmp.setEmpProfilePhoneNo(_emp.getEmpProfilePhoneNo());
            
        	oldEmp.setEmpProfileMailId(_emp.getEmpProfileMailId());
            
        	oldEmp.setEmpProfileSignTiff(_emp.getEmpProfileSignTiff());
            
        	oldEmp.setEmpProfileSuperiorUserId(_emp.getEmpProfileSuperiorUserId());
            
        	oldEmp.setEmpProfileNotes(_emp.getEmpProfileNotes());
            
        	oldEmp.setEmpProfileGroupId(_emp.getEmpProfileGroupId());
            
        	oldEmp.setEmpProfilePenWidth(_emp.getEmpProfilePenWidth());
            
        	oldEmp.setEmpProfilePenColor(_emp.getEmpProfilePenColor());
            
        	oldEmp.setProfile(_emp.getProfile());
            
        	oldEmp.setEmpProfileStatus(_emp.getEmpProfileStatus());
            
        	oldEmp.setH555555(_emp.getH555555());
            
        	oldEmp.setEmpProfileIsPrevEncounter(_emp.getEmpProfileIsPrevEncounter());
            
        	oldEmp.setEmpProfileIsRevMedication(_emp.getEmpProfileIsRevMedication());
            
        	oldEmp.setEmpProfilePrivateKey(_emp.getEmpProfilePrivateKey());
            
        	oldEmp.setEmpProfilePublicKey(_emp.getEmpProfilePublicKey());
            
        	oldEmp.setEmpProfilePrescriptionHeaderId(_emp.getEmpProfilePrescriptionHeaderId());
            
        	oldEmp.setEmpProfileShowServiceCharges(_emp.getEmpProfileShowServiceCharges());
            
        	oldEmp.setEmpProfileSSUnknown(_emp.getEmpProfileSSUnknown());
            
        	oldEmp.setEmpProfileVisitType(_emp.getEmpProfileVisitType());
            
        	oldEmp.setEmpProfileNeedInvoice(_emp.getEmpProfileNeedInvoice());
            
        	oldEmp.setEmpProfileLastPatchDisableDate(_emp.getEmpProfileLastPatchDisableDate());
            
        	oldEmp.setSyncStatus(_emp.getSyncStatus());
            
        	oldEmp.setEmpProfileIsEmergencyAccess(_emp.getEmpProfileIsEmergencyAccess());
            
        	oldEmp.setEmpProfileRsaSecureKey(_emp.getEmpProfileRsaSecureKey());
            
        	oldEmp.setEmpProfileSpeciality(_emp.getEmpProfileSpeciality());
            
        	oldEmp.setEmpProfileDirectMailId(_emp.getEmpProfileDirectMailId());
            
        	oldEmp.setEmpProfileModifiedDate(_emp.getEmpProfileModifiedDate());
            
        	oldEmp.setEmpProfileModifiedBy(_emp.getEmpProfileModifiedBy());
            
        	oldEmp.setEmpProfileCtpNumber(_emp.getEmpProfileCtpNumber());
            
        	oldEmp.setEmpProfileFaxId(_emp.getEmpProfileFaxId());
            
        	oldEmp.setEmpProfileTaxId(_emp.getEmpProfileTaxId());
            
        	oldEmp.setEmpProfilePayToAddress(_emp.getEmpProfilePayToAddress());
            
        	oldEmp.setEmpProfileIsSignAccess(_emp.getEmpProfileIsSignAccess());
            
        	oldEmp.setEmpProfileSupervisorId(_emp.getEmpProfileSupervisorId());
            
        	oldEmp.setEmpProfilePrefix(_emp.getEmpProfilePrefix());
            
        	oldEmp.setEmpProfileSuffix(_emp.getEmpProfileSuffix());
            
        	oldEmp.setEmpProfileIsForwardForCosign(_emp.getEmpProfileIsForwardForCosign());
            
        	oldEmp.setEmpProfileInvoice(_emp.getEmpProfileInvoice());
            
        	oldEmp.setEmpProfileCreatedBy(_emp.getEmpProfileCreatedBy());
            
        	oldEmp.setEmpProfileCreatedDate(_emp.getEmpProfileCreatedDate());
            
        	oldEmp.setEmpProfileInactivatedOn(_emp.getEmpProfileInactivatedOn());
            
        	oldEmp.setEmpProfileMedTunnalMailId(_emp.getEmpProfileMedTunnalMailId());
        
        	oldEmp.setEmpProfileErxOtpKey(_emp.getEmpProfileErxOtpKey());
            
        	oldEmp.setEmpProfileProviderMapId(_emp.getEmpProfileProviderMapId());

            return repos.save(oldEmp);
        } 
        
        else {
        	
            return null;
        
        }
        
        }
    
    public String deleteid(int empId) {
    	 
    	repos.deleteById(empId);
        
    	return empId + " deleted";
    }
     
     
    public List<EmployeeEntity> table(EmployeeEntity _emp) {
    	
    	return repos.tabledata(_emp);
    }
    
    public List<EmployeeEntity> id(EmployeeEntity _emp){
    	
    	return repos.ids(_emp);
    }
    
    //  ------ reading the table ---- criteria query
    
    public List<EmployeeEntity> tabledata(EmployeeEntity _emp){
    	
    	return cq.getAllEmployees();
    }
    
    // ----- getting the data through id
    
    public List<EmployeeEntity> idemp(int empId){
    	
    	return cq.findingbyempid(empId);
    }
    
    
    }




   
    
    
