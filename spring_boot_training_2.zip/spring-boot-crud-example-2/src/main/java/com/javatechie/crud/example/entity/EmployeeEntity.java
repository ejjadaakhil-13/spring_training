package com.javatechie.crud.example.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.sql.Timestamp;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "emp_profile")
public class EmployeeEntity {

    @Id
    @Column(name = "emp_profile_empid")
    private Integer empId;

    @Column(name = "emp_profile_loginid", nullable = false)
    private Integer loginId;

    @Column(name = "emp_profile_doctorid", nullable = false, length = 5)
    private String doctorId;

    @Column(name = "emp_profile_lname", length = 255)
    private String profileLname;

    @Column(name = "emp_profile_mi", length = 2)
    private String profileMi;

    @Column(name = "emp_profile_fname", length = 255)
    private String profileFname;

    @Column(name = "emp_profile_fullname", length = 255)
    private String profileFullname;

    @Column(name = "emp_profile_credentials", length = 100)
    private String profileCredentials;

    @Column(name = "emp_profile_ssn", length = 15)
    private String profileSsn;

    @Column(name = "emp_profile_address", length = 255)
    private String empProfileAddress;

    @Column(name = "emp_profile_city", length = 255)
    private String empProfileCity;

    @Column(name = "emp_profile_state", length = 2)
    private String empProfileState;

    @Column(name = "emp_profile_zip", length = 255)
    private String empProfileZip;

    @Column(name = "emp_profile_phoneno", length = 20)
    private String empProfilePhoneNo;

    @Column(name = "emp_profile_mailid", length = 255)
    private String empProfileMailId;

    @Column(name = "emp_profile_sign_tiff", length = 255)
    private String empProfileSignTiff;

    @Column(name = "emp_profile_superioruserid")
    private Integer empProfileSuperiorUserId;

    @Column(name = "emp_profile_notes", length = 255)
    private String empProfileNotes;

    @Column(name = "emp_profile_groupid")
    private Integer empProfileGroupId;

    @Column(name = "emp_profile_penwidth")
    private Short empProfilePenWidth;

    @Column(name = "emp_profile_pencolor")
    private Short empProfilePenColor;

    @Column(name = "emp_profile_is_active", nullable = false)
    private Boolean profile = true;

    @Column(name = "emp_profile_status")
    private Short empProfileStatus;

    @Column(name = "h555555", columnDefinition = "integer default 1")
    private Integer h555555;

    @Column(name = "emp_profile_isprevencounter", columnDefinition = "boolean default false")
    private Boolean empProfileIsPrevEncounter;

    @Column(name = "emp_profile_isrevmedication", columnDefinition = "boolean default false")
    private Boolean empProfileIsRevMedication;

    @Column(name = "emp_profile_privatekey", columnDefinition = "text default ''")
    private String empProfilePrivateKey;

    @Column(name = "emp_profile_publickey", columnDefinition = "text default ''")
    private String empProfilePublicKey;

    @Column(name = "emp_profile_prescriptionheaderid")
    private Integer empProfilePrescriptionHeaderId;

    @Column(name = "emp_profile_showservicecharges")
    private Integer empProfileShowServiceCharges;

    @Column(name = "emp_profile_ssunknown", length = 100)
    private String empProfileSSUnknown;

    @Column(name = "emp_profile_visittype")
    private Integer empProfileVisitType;

    @Column(name = "emp_profile_needinvoice")
    private Integer empProfileNeedInvoice;

    @Column(name = "emp_profile_lastpatchdisabledate")
    private Timestamp empProfileLastPatchDisableDate;

    @Column(name = "syncstatus")
    private Integer syncStatus;

    @Column(name = "emp_profile_isemergencyaccess", columnDefinition = "boolean default true")
    private Boolean empProfileIsEmergencyAccess;

    @Column(name = "emp_profile_rsa_secure_key")
    private String empProfileRsaSecureKey;

    @Column(name = "emp_profile_speciality")
    private Integer empProfileSpeciality;

    @Column(name = "emp_profile_direct_mailid", length = 255)
    private String empProfileDirectMailId;

    @Column(name = "emp_profile_modified_date")
    @UpdateTimestamp
    private Timestamp empProfileModifiedDate;

    @Column(name = "emp_profile_modified_by", length = 30)
    private String empProfileModifiedBy;

    @Column(name = "emp_profile_ctp_number", length = 50)
    private String empProfileCtpNumber;

    @Column(name = "emp_profile_fax_id", length = 30)
    private String empProfileFaxId;

    @Column(name = "emp_profile_tax_id", length = 30)
    private String empProfileTaxId;

    @Column(name = "emp_profile_payto_address", length = 255)
    private String empProfilePayToAddress;

    @Column(name = "emp_profile_issignaccess")
    private Boolean empProfileIsSignAccess;

    @Column(name = "emp_profile_supervisorid", columnDefinition = "integer default -1")
    private Integer empProfileSupervisorId;

    @Column(name = "emp_profile_prefix", length = 25)
    private String empProfilePrefix;

    @Column(name = "emp_profile_suffix", length = 25)
    private String empProfileSuffix;

    @Column(name = "emp_profile_isforward_forcosign")
    private Boolean empProfileIsForwardForCosign;

    @Column(name = "emp_profile_invoice", columnDefinition = "boolean default false")
    private Boolean empProfileInvoice;

    @Column(name = "emp_profile_created_by", length = 250)
    private String empProfileCreatedBy;

    @Column(name = "emp_profile_created_date", updatable = false, columnDefinition = "timestamp default now()")
    @CreationTimestamp
    @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private Timestamp empProfileCreatedDate;

    @Column(name = "emp_profile_inactivated_on")
    @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private Timestamp empProfileInactivatedOn;

    @Column(name = "emp_profile_medtunnal_mailid", length = 255)
    private String empProfileMedTunnalMailId;

    @Column(name = "emp_profile_erx_otp_key", length = 250)
    private String empProfileErxOtpKey;

    @Column(name = "emp_profile_provider_map_id")
    private Integer empProfileProviderMapId;

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public Integer getLoginId() {
		return loginId;
	}

	public void setLoginId(Integer loginId) {
		this.loginId = loginId;
	}

	public String getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId;
	}

	public String getProfileLname() {
		return profileLname;
	}

	public void setProfileLname(String profileLname) {
		this.profileLname = profileLname;
	}

	public String getProfileMi() {
		return profileMi;
	}

	public void setProfileMi(String profileMi) {
		this.profileMi = profileMi;
	}

	public String getProfileFname() {
		return profileFname;
	}

	public void setProfileFname(String profileFname) {
		this.profileFname = profileFname;
	}

	public String getProfileFullname() {
		return profileFullname;
	}

	public void setProfileFullname(String profileFullname) {
		this.profileFullname = profileFullname;
	}

	public String getProfileCredentials() {
		return profileCredentials;
	}

	public void setProfileCredentials(String profileCredentials) {
		this.profileCredentials = profileCredentials;
	}

	public String getProfileSsn() {
		return profileSsn;
	}

	public void setProfileSsn(String profileSsn) {
		this.profileSsn = profileSsn;
	}

	public String getEmpProfileAddress() {
		return empProfileAddress;
	}

	public void setEmpProfileAddress(String empProfileAddress) {
		this.empProfileAddress = empProfileAddress;
	}

	public String getEmpProfileCity() {
		return empProfileCity;
	}

	public void setEmpProfileCity(String empProfileCity) {
		this.empProfileCity = empProfileCity;
	}

	public String getEmpProfileState() {
		return empProfileState;
	}

	public void setEmpProfileState(String empProfileState) {
		this.empProfileState = empProfileState;
	}

	public String getEmpProfileZip() {
		return empProfileZip;
	}

	public void setEmpProfileZip(String empProfileZip) {
		this.empProfileZip = empProfileZip;
	}

	public String getEmpProfilePhoneNo() {
		return empProfilePhoneNo;
	}

	public void setEmpProfilePhoneNo(String empProfilePhoneNo) {
		this.empProfilePhoneNo = empProfilePhoneNo;
	}

	public String getEmpProfileMailId() {
		return empProfileMailId;
	}

	public void setEmpProfileMailId(String empProfileMailId) {
		this.empProfileMailId = empProfileMailId;
	}

	public String getEmpProfileSignTiff() {
		return empProfileSignTiff;
	}

	public void setEmpProfileSignTiff(String empProfileSignTiff) {
		this.empProfileSignTiff = empProfileSignTiff;
	}

	public Integer getEmpProfileSuperiorUserId() {
		return empProfileSuperiorUserId;
	}

	public void setEmpProfileSuperiorUserId(Integer empProfileSuperiorUserId) {
		this.empProfileSuperiorUserId = empProfileSuperiorUserId;
	}

	public String getEmpProfileNotes() {
		return empProfileNotes;
	}

	public void setEmpProfileNotes(String empProfileNotes) {
		this.empProfileNotes = empProfileNotes;
	}

	public Integer getEmpProfileGroupId() {
		return empProfileGroupId;
	}

	public void setEmpProfileGroupId(Integer empProfileGroupId) {
		this.empProfileGroupId = empProfileGroupId;
	}

	public Short getEmpProfilePenWidth() {
		return empProfilePenWidth;
	}

	public void setEmpProfilePenWidth(Short empProfilePenWidth) {
		this.empProfilePenWidth = empProfilePenWidth;
	}

	public Short getEmpProfilePenColor() {
		return empProfilePenColor;
	}

	public void setEmpProfilePenColor(Short empProfilePenColor) {
		this.empProfilePenColor = empProfilePenColor;
	}

	public Boolean getProfile() {
		return profile;
	}

	public void setProfile(Boolean profile) {
		this.profile = profile;
	}

	public Short getEmpProfileStatus() {
		return empProfileStatus;
	}

	public void setEmpProfileStatus(Short empProfileStatus) {
		this.empProfileStatus = empProfileStatus;
	}

	public Integer getH555555() {
		return h555555;
	}

	public void setH555555(Integer h555555) {
		this.h555555 = h555555;
	}

	public Boolean getEmpProfileIsPrevEncounter() {
		return empProfileIsPrevEncounter;
	}

	public void setEmpProfileIsPrevEncounter(Boolean empProfileIsPrevEncounter) {
		this.empProfileIsPrevEncounter = empProfileIsPrevEncounter;
	}

	public Boolean getEmpProfileIsRevMedication() {
		return empProfileIsRevMedication;
	}

	public void setEmpProfileIsRevMedication(Boolean empProfileIsRevMedication) {
		this.empProfileIsRevMedication = empProfileIsRevMedication;
	}

	public String getEmpProfilePrivateKey() {
		return empProfilePrivateKey;
	}

	public void setEmpProfilePrivateKey(String empProfilePrivateKey) {
		this.empProfilePrivateKey = empProfilePrivateKey;
	}

	public String getEmpProfilePublicKey() {
		return empProfilePublicKey;
	}

	public void setEmpProfilePublicKey(String empProfilePublicKey) {
		this.empProfilePublicKey = empProfilePublicKey;
	}

	public Integer getEmpProfilePrescriptionHeaderId() {
		return empProfilePrescriptionHeaderId;
	}

	public void setEmpProfilePrescriptionHeaderId(Integer empProfilePrescriptionHeaderId) {
		this.empProfilePrescriptionHeaderId = empProfilePrescriptionHeaderId;
	}

	public Integer getEmpProfileShowServiceCharges() {
		return empProfileShowServiceCharges;
	}

	public void setEmpProfileShowServiceCharges(Integer empProfileShowServiceCharges) {
		this.empProfileShowServiceCharges = empProfileShowServiceCharges;
	}

	public String getEmpProfileSSUnknown() {
		return empProfileSSUnknown;
	}

	public void setEmpProfileSSUnknown(String empProfileSSUnknown) {
		this.empProfileSSUnknown = empProfileSSUnknown;
	}

	public Integer getEmpProfileVisitType() {
		return empProfileVisitType;
	}

	public void setEmpProfileVisitType(Integer empProfileVisitType) {
		this.empProfileVisitType = empProfileVisitType;
	}

	public Integer getEmpProfileNeedInvoice() {
		return empProfileNeedInvoice;
	}

	public void setEmpProfileNeedInvoice(Integer empProfileNeedInvoice) {
		this.empProfileNeedInvoice = empProfileNeedInvoice;
	}

	public Timestamp getEmpProfileLastPatchDisableDate() {
		return empProfileLastPatchDisableDate;
	}

	public void setEmpProfileLastPatchDisableDate(Timestamp empProfileLastPatchDisableDate) {
		this.empProfileLastPatchDisableDate = empProfileLastPatchDisableDate;
	}

	public Integer getSyncStatus() {
		return syncStatus;
	}

	public void setSyncStatus(Integer syncStatus) {
		this.syncStatus = syncStatus;
	}

	public Boolean getEmpProfileIsEmergencyAccess() {
		return empProfileIsEmergencyAccess;
	}

	public void setEmpProfileIsEmergencyAccess(Boolean empProfileIsEmergencyAccess) {
		this.empProfileIsEmergencyAccess = empProfileIsEmergencyAccess;
	}

	public String getEmpProfileRsaSecureKey() {
		return empProfileRsaSecureKey;
	}

	public void setEmpProfileRsaSecureKey(String empProfileRsaSecureKey) {
		this.empProfileRsaSecureKey = empProfileRsaSecureKey;
	}

	public Integer getEmpProfileSpeciality() {
		return empProfileSpeciality;
	}

	public void setEmpProfileSpeciality(Integer empProfileSpeciality) {
		this.empProfileSpeciality = empProfileSpeciality;
	}

	public String getEmpProfileDirectMailId() {
		return empProfileDirectMailId;
	}

	public void setEmpProfileDirectMailId(String empProfileDirectMailId) {
		this.empProfileDirectMailId = empProfileDirectMailId;
	}

	public Timestamp getEmpProfileModifiedDate() {
		return empProfileModifiedDate;
	}

	public void setEmpProfileModifiedDate(Timestamp empProfileModifiedDate) {
		this.empProfileModifiedDate = empProfileModifiedDate;
	}

	public String getEmpProfileModifiedBy() {
		return empProfileModifiedBy;
	}

	public void setEmpProfileModifiedBy(String empProfileModifiedBy) {
		this.empProfileModifiedBy = empProfileModifiedBy;
	}

	public String getEmpProfileCtpNumber() {
		return empProfileCtpNumber;
	}

	public void setEmpProfileCtpNumber(String empProfileCtpNumber) {
		this.empProfileCtpNumber = empProfileCtpNumber;
	}

	public String getEmpProfileFaxId() {
		return empProfileFaxId;
	}

	public void setEmpProfileFaxId(String empProfileFaxId) {
		this.empProfileFaxId = empProfileFaxId;
	}

	public String getEmpProfileTaxId() {
		return empProfileTaxId;
	}

	public void setEmpProfileTaxId(String empProfileTaxId) {
		this.empProfileTaxId = empProfileTaxId;
	}

	public String getEmpProfilePayToAddress() {
		return empProfilePayToAddress;
	}

	public void setEmpProfilePayToAddress(String empProfilePayToAddress) {
		this.empProfilePayToAddress = empProfilePayToAddress;
	}

	public Boolean getEmpProfileIsSignAccess() {
		return empProfileIsSignAccess;
	}

	public void setEmpProfileIsSignAccess(Boolean empProfileIsSignAccess) {
		this.empProfileIsSignAccess = empProfileIsSignAccess;
	}

	public Integer getEmpProfileSupervisorId() {
		return empProfileSupervisorId;
	}

	public void setEmpProfileSupervisorId(Integer empProfileSupervisorId) {
		this.empProfileSupervisorId = empProfileSupervisorId;
	}

	public String getEmpProfilePrefix() {
		return empProfilePrefix;
	}

	public void setEmpProfilePrefix(String empProfilePrefix) {
		this.empProfilePrefix = empProfilePrefix;
	}

	public String getEmpProfileSuffix() {
		return empProfileSuffix;
	}

	public void setEmpProfileSuffix(String empProfileSuffix) {
		this.empProfileSuffix = empProfileSuffix;
	}

	public Boolean getEmpProfileIsForwardForCosign() {
		return empProfileIsForwardForCosign;
	}

	public void setEmpProfileIsForwardForCosign(Boolean empProfileIsForwardForCosign) {
		this.empProfileIsForwardForCosign = empProfileIsForwardForCosign;
	}

	public Boolean getEmpProfileInvoice() {
		return empProfileInvoice;
	}

	public void setEmpProfileInvoice(Boolean empProfileInvoice) {
		this.empProfileInvoice = empProfileInvoice;
	}

	public String getEmpProfileCreatedBy() {
		return empProfileCreatedBy;
	}

	public void setEmpProfileCreatedBy(String empProfileCreatedBy) {
		this.empProfileCreatedBy = empProfileCreatedBy;
	}

	public Timestamp getEmpProfileCreatedDate() {
		return empProfileCreatedDate;
	}

	public void setEmpProfileCreatedDate(Timestamp empProfileCreatedDate) {
		this.empProfileCreatedDate = empProfileCreatedDate;
	}

	public Timestamp getEmpProfileInactivatedOn() {
		return empProfileInactivatedOn;
	}

	public void setEmpProfileInactivatedOn(Timestamp empProfileInactivatedOn) {
		this.empProfileInactivatedOn = empProfileInactivatedOn;
	}

	public String getEmpProfileMedTunnalMailId() {
		return empProfileMedTunnalMailId;
	}

	public void setEmpProfileMedTunnalMailId(String empProfileMedTunnalMailId) {
		this.empProfileMedTunnalMailId = empProfileMedTunnalMailId;
	}

	public String getEmpProfileErxOtpKey() {
		return empProfileErxOtpKey;
	}

	public void setEmpProfileErxOtpKey(String empProfileErxOtpKey) {
		this.empProfileErxOtpKey = empProfileErxOtpKey;
	}

	public Integer getEmpProfileProviderMapId() {
		return empProfileProviderMapId;
	}

	public void setEmpProfileProviderMapId(Integer empProfileProviderMapId) {
		this.empProfileProviderMapId = empProfileProviderMapId;
	}

    
}
